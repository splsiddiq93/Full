/*
 * Siddiq Mohamed
 * 17 May 2017
 * isOneOrSum10
 * 
 * */
import java.util.Scanner;

public class MainController {

	public static void main(String args[]) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the a value");
		int a = scan.nextInt();
		System.out.println("Enter the b value");
		int b = scan.nextInt();
		boolean m = IsOneOrSum.isOneOrSum10(a, b);

		if (m == true) {
			System.out.println("true");
		} else {
			System.out.println("false");
		}
	}
}
