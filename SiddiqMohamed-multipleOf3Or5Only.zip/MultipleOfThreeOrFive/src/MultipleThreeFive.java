/*Siddiq Mohamed
01/06/2017
multipleOf3Or5Only*/

public class MultipleThreeFive {

	public boolean multipleOf3Or5Only(int n) {
		if (n % 3 == 0 && n % 5 == 0) {
			return false;
		} else if (n % 3 == 0 || n % 5 == 0) {
			return true;
		}
		return false;
	}

	public static void main(String args[]) {
		MultipleThreeFive obj = new MultipleThreeFive();

		// Test case 1
		int number = 25;
		boolean result = obj.multipleOf3Or5Only(number);
		if (result == true) {
			System.out.println("Test Passes");
		} else {
			System.out.println("Test Failed!");
		}

		// Test case 2
		number = 26;
		result = obj.multipleOf3Or5Only(number);
		if (result == false) {
			System.out.println("Test Passes");
		} else {
			System.out.println("Test Failed!");
		}

		// Test case 3
		number = 15;
		result = obj.multipleOf3Or5Only(number);
		if (result == false) {
			System.out.println("Test Passes");
		} else {
			System.out.println("Test Failed!");
		}

		// Test case 4
		number = 6;
		result = obj.multipleOf3Or5Only(number);
		if (result == true) {
			System.out.println("Test Passes");
		} else {
			System.out.println("Test Failed!");
		}

		// Test case 5
		number = 35;
		result = obj.multipleOf3Or5Only(number);
		if (result == true) {
			System.out.println("Test Passes");
		} else {
			System.out.println("Test Failed!");
		}

		// Test case 6
		number = 60;
		result = obj.multipleOf3Or5Only(number);
		if (result == false) {
			System.out.println("Test Passes");
		} else {
			System.out.println("Test Failed!");
		}

		// Test case 7
		number = 30;
		result = obj.multipleOf3Or5Only(number);
		if (result == false) {
			System.out.println("Test Passes");
		} else {
			System.out.println("Test Failed!");
		}

		// Test case 8
		number = 32;
		result = obj.multipleOf3Or5Only(number);
		if (result == false) {
			System.out.println("Test Passes");
		} else {
			System.out.println("Test Failed!");
		}

		// Test case 9
		number = 50;
		result = obj.multipleOf3Or5Only(number);
		if (result == true) {
			System.out.println("Test Passes");
		} else {
			System.out.println("Test Failed!");
		}
	}
}
