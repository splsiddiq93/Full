package com.full.notes.model;

public enum Color {
    WHITE, RED, ORANGE, YELLOW, GREY, DARK_BLUE, LIGTH_BLUE, GREEN
}
