package com.full.notes.model;

public class Collaborator {
	private String email;
	private String photoUrl;
}
