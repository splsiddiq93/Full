/*Siddiq Mohamed
01/06/2017
multipleOf3Or5Only*/

import java.util.Scanner;

public class MainController {
	
	public static void main(String args[]) {
		Scanner scan = new Scanner(System.in);
		MultipleThreeFive obj = new MultipleThreeFive();
		System.out.println("Please enter a number");
		int input = scan.nextInt();
		boolean result = obj.multipleOf3Or5Only(input);
		System.out.println(result);
		scan.close();
	}
}
