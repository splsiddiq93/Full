package com.full.notes.model;

public class NoteReminder {
	private long reminderTime;
	private boolean isDeleted;
}
