package com.full.notes.model;
import java.util.List;

public class User {

	private long id;
	private String email;  // Google account email address of the USER
	private List<Note> notes;
	private List<String> labelOptions;
	
}
