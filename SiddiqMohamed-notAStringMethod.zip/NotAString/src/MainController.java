
/*Siddiq Mohamed
 * 17/05/2017
 * notAString method
 * */
import java.util.Scanner;

public class MainController {

	public static void main(String args[]) {

		Scanner input = new Scanner(System.in);
		System.out.println("Enter a String");
		String notAString = input.nextLine();
		String result = NotAStringClass.notAString(notAString);
		System.out.println(result);

	}
}
