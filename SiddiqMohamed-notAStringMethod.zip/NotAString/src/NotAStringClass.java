/*Siddiq Mohamed
 * 17/05/2017
 * notAString method
 * */
import java.util.ArrayList;

public class NotAStringClass {

	public static String notAString(String s) {
		ArrayList<String> list = new ArrayList<>();
		int l = s.length();
		String b[] = { "not" };
		String ans = "";
		for (int i = 0; i < l; i++) {
			char ch = s.charAt(i);
			if (ch == ' ') {
				list.add(ans);
				ans = "";
			} else if (i + 1 == l) {
				ans = ans + ch;
				list.add(ans);
			} else {
				ans = ans + ch;
			}
		}
		if (list.get(0).equals(b[0])) {
		} else {
			String si = "not" + " " + s;
			return si;
		}
		return s;
	}

	public static void main(String[] args) {

		// Test case 1
		{
			String a = "going to happen";
			String expectedOutput = "not going to happen";
			String b = NotAStringClass.notAString(a);
			if (b.equals(expectedOutput)) {
				System.out.println("Test Passes");
			} else
				System.out.println("Test Failed");
		}

		// Test case 2
		{
			String a = "not interested";
			String expectedOutput = "not interested";
			String b = NotAStringClass.notAString(a);
			if (b.equals(expectedOutput)) {
				System.out.println("Test Passes");
			} else
				System.out.println("Test Failed");
		}

		// Test case 3
		{
			String a = "a";
			String expectedOutput = "not a";
			String b = NotAStringClass.notAString(a);
			if (b.equals(expectedOutput)) {
				System.out.println("Test Passes");
			} else
				System.out.println("Test Failed");
		}
	}
}
