/*
 * Siddiq Mohamed
 * 17 May 2017
 * isOneOrSum10
 * 
 * */
public class IsOneOrSum {

	//Method that tests the cases
	public static boolean isOneOrSum10(int a, int b) {
		int c = a + b;
		if (a == 10) {
			return true;
		} else if (b == 10) {
			return true;
		} else if (c == 10) {
			return true;
		}
		return false;
	}

	public static void main(String args[]) {

		// Test case 1
		{
			int a = 9;
			int b = 10;
			boolean c = IsOneOrSum.isOneOrSum10(a, b);
			if (c == true) {
				System.out.println("Test passes");
			} else {
				System.out.println("Test failed!");
			}
		}
		// Test case 2
		{
			int a = 9;
			int b = 9;
			boolean c = IsOneOrSum.isOneOrSum10(a, b);
			if (c == false) {
				System.out.println("Test passes");
			} else {
				System.out.println("Test failed!");
			}
		}

		// Test case 3
		{
			int a = 1;
			int b = 9;
			boolean c = IsOneOrSum.isOneOrSum10(a, b);
			if (c == true) {
				System.out.println("Test passes");
			} else {
				System.out.println("Test failed!");
			}
		}
	}

}
